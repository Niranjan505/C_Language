#include <stdio.h>
#include <conio.h>

main()
{
   int num,index,ans;
   clrscr();
   printf("Enter the numbar= ");
   scanf("%d",&num);
        printf("%d ×1 = %d\n", num ,num*1,ans); 
        printf("%d ×2 = %d\n", num ,num*2,ans);
        printf("%d ×3 = %d\n", num ,num*3,ans);
        printf("%d ×4 = %d\n", num ,num*4,ans);
        printf("%d ×5 = %d\n", num ,num*5,ans);
        printf("%d ×6 = %d\n", num ,num*6,ans); 
        printf("%d ×7 = %d\n", num ,num*7,ans);
        printf("%d ×8 = %d\n", num ,num*8,ans);
        printf("%d ×9 = %d\n", num ,num*9,ans);
        printf("%d ×10= %d\n", num ,num*10,ans);
     getch();
         
}